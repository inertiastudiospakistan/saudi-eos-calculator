// Top-level build file — Saudi EOS Calculator (com.inertia.eoscalc).
// Distinct build identity for this app only: Kotlin DSL + version catalog,
// no shared template with any other app in the series.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.ksp) apply false
}
