# Privacy Policy — Saudi EOS Calculator (com.inertia.eoscalc)

Last updated: 20 November 2026

## Short version

This app collects, stores, transmits and shares **no personal data at all**.
It works fully offline. There is no account, no login, no advertising,
no analytics, no tracking, and no internet connection of any kind.

## What the app does with your input

The wage, service length and reason for leaving that you type are used
only on your device, in the moment, to calculate your end-of-service
award. They are never sent anywhere, because the app has no internet
permission and makes no network requests.

## Saved calculations (History)

If you tap **Save**, that one calculation is stored in a database on
your own device (Android Room database, `eos-history.db`). It stays on
the device, is never uploaded or shared, and is deleted when you delete
a saved item, clear the history, or uninstall the app.

## Permissions

The app requests **no permissions** — no internet, no location, no
contacts, no files, no camera, no microphone.

## Third parties

No third-party SDKs are included. No data is shared with any third
party, because no data leaves the device.

## Children

The app is a general-purpose calculator. It collects no data from
anyone, including children.

## Changes

If this policy ever changes, the updated version will be published
here and the app updated accordingly.

## Contact

Questions about this policy: contact the developer through the
Google Play store listing.
