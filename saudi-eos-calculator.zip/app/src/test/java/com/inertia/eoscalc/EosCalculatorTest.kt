package com.inertia.eoscalc

import com.inertia.eoscalc.domain.EosCalculator
import com.inertia.eoscalc.domain.LeavingReason
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import java.time.LocalDate

/**
 * Unit tests for the Art. 84 / Art. 85 logic. The three worked checks are
 * the same numbers hand-verified in the companion web calculator:
 *   10,000 SAR, 7 yrs, employer-ended  -> 45,000 (25,000 + 20,000)
 *   10,000 SAR, 7 yrs, resignation    -> 30,000 (45,000 x 2/3)
 *   10,000 SAR, 3 yrs, resignation    ->  5,000 (15,000 x 1/3)
 *   10,000 SAR, 12 yrs, employer      -> 95,000 (25,000 + 70,000)
 */
class EosCalculatorTest {

    private val delta = 0.001

    @Test
    fun employerEnded_sevenYears_is45000() {
        val r = EosCalculator.calculate(10_000.0, 7.0, LeavingReason.EMPLOYER)
        assertEquals(25_000.0, r.firstPart, delta)
        assertEquals(20_000.0, r.afterPart, delta)
        assertEquals(45_000.0, r.gross, delta)
        assertEquals(45_000.0, r.finalAmount, delta)
        assertEquals(4.5, r.monthsEquivalent, delta)
    }

    @Test
    fun resignation_sevenYears_is30000_twoThirds() {
        val r = EosCalculator.calculate(10_000.0, 7.0, LeavingReason.RESIGNATION)
        assertEquals(45_000.0, r.gross, delta)
        assertEquals(2.0 / 3.0, r.entitlementFactor, delta)
        assertEquals(2, r.tierIndex)
        assertEquals(30_000.0, r.finalAmount, delta)
    }

    @Test
    fun resignation_threeYears_is5000_oneThird() {
        val r = EosCalculator.calculate(10_000.0, 3.0, LeavingReason.RESIGNATION)
        assertEquals(15_000.0, r.gross, delta)
        assertEquals(1.0 / 3.0, r.entitlementFactor, delta)
        assertEquals(5_000.0, r.finalAmount, delta)
    }

    @Test
    fun employerEnded_twelveYears_is95000() {
        val r = EosCalculator.calculate(10_000.0, 12.0, LeavingReason.EMPLOYER)
        assertEquals(25_000.0, r.firstPart, delta)
        assertEquals(70_000.0, r.afterPart, delta)
        assertEquals(95_000.0, r.finalAmount, delta)
    }

    @Test
    fun resignation_underTwoYears_isZero() {
        val r = EosCalculator.calculate(10_000.0, 1.5, LeavingReason.RESIGNATION)
        assertEquals(0.0, r.entitlementFactor, delta)
        assertEquals(0, r.tierIndex)
        assertEquals(0.0, r.finalAmount, delta)
    }

    @Test
    fun resignation_tenYears_isFull() {
        val r = EosCalculator.calculate(10_000.0, 10.0, LeavingReason.RESIGNATION)
        assertEquals(1.0, r.entitlementFactor, delta)
        assertEquals(3, r.tierIndex)
        assertEquals(75_000.0, r.finalAmount, delta) // 25,000 + 5 x 10,000 = 75,000
    }

    @Test
    fun contractEnd_shortService_isFull() {
        // Fixed-term expiry is NOT a resignation: full award at any length.
        val r = EosCalculator.calculate(8_000.0, 1.0, LeavingReason.CONTRACT_END)
        assertEquals(4_000.0, r.finalAmount, delta)
    }

    @Test
    fun monthsAreProRata() {
        // 7 years 6 months, employer-ended: 25,000 + 2.5 x 10,000 = 50,000.
        val years = EosCalculator.serviceYearsFromParts(7, 6)
        assertEquals(7.5, years, delta)
        val r = EosCalculator.calculate(10_000.0, years, LeavingReason.EMPLOYER)
        assertEquals(50_000.0, r.finalAmount, delta)
    }

    @Test
    fun datesGiveSameYearsAsParts() {
        val years = EosCalculator.serviceYearsFromDates(
            LocalDate.of(2019, 1, 1), LocalDate.of(2026, 1, 1)
        )
        assertEquals(7.0, years, delta)
        val r = EosCalculator.calculate(10_000.0, years, LeavingReason.EMPLOYER)
        assertEquals(45_000.0, r.finalAmount, delta)
    }

    @Test
    fun dates_endBeforeStart_throws() {
        assertThrows(IllegalArgumentException::class.java) {
            EosCalculator.serviceYearsFromDates(
                LocalDate.of(2026, 1, 1), LocalDate.of(2019, 1, 1)
            )
        }
    }

    @Test
    fun zeroWage_throws() {
        assertThrows(IllegalArgumentException::class.java) {
            EosCalculator.calculate(0.0, 7.0, LeavingReason.EMPLOYER)
        }
    }

    @Test
    fun negativeWage_throws() {
        assertThrows(IllegalArgumentException::class.java) {
            EosCalculator.calculate(-5_000.0, 7.0, LeavingReason.EMPLOYER)
        }
    }

    @Test
    fun zeroService_throws() {
        assertThrows(IllegalArgumentException::class.java) {
            EosCalculator.calculate(10_000.0, 0.0, LeavingReason.EMPLOYER)
        }
    }

    @Test
    fun monthsOutOfRange_throws() {
        assertThrows(IllegalArgumentException::class.java) {
            EosCalculator.serviceYearsFromParts(7, 12)
        }
    }

    @Test
    fun exactlyFiveYears_isBoundary() {
        // Exactly 5 years: all at half a month, nothing at a full month.
        val r = EosCalculator.calculate(10_000.0, 5.0, LeavingReason.EMPLOYER)
        assertEquals(25_000.0, r.firstPart, delta)
        assertEquals(0.0, r.afterPart, delta)
        assertEquals(25_000.0, r.finalAmount, delta)
    }
}
