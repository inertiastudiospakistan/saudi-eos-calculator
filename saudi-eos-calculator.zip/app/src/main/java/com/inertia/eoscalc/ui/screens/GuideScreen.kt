package com.inertia.eoscalc.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.inertia.eoscalc.R

/**
 * Guide tab — the law, explained. Same facts as the web tool
 * (Arts. 84/85, worked example, FAQ, special cases), laid out as
 * stacked guide cards rather than a web page.
 */
@Composable
fun GuideScreen(onLoadExample: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        GuideCard(stringResource(R.string.art84_title)) {
            Text(stringResource(R.string.art84_body), style = MaterialTheme.typography.bodyMedium)
        }
        GuideCard(stringResource(R.string.art85_title)) {
            Text(stringResource(R.string.art85_body), style = MaterialTheme.typography.bodyMedium)
        }
        GuideCard(stringResource(R.string.example_title)) {
            Text(stringResource(R.string.example_intro), style = MaterialTheme.typography.bodyMedium)
            Text(stringResource(R.string.example_steps), style = MaterialTheme.typography.bodyMedium)
            Button(
                onClick = onLoadExample,
                modifier = Modifier.fillMaxWidth().height(48.dp),
            ) { Text(stringResource(R.string.try_example)) }
        }
        GuideCard(stringResource(R.string.special_title)) {
            Text(stringResource(R.string.special_body), style = MaterialTheme.typography.bodyMedium)
        }
        GuideCard(stringResource(R.string.faq_title)) {
            FaqItem(stringResource(R.string.faq_q1), stringResource(R.string.faq_a1))
            FaqItem(stringResource(R.string.faq_q2), stringResource(R.string.faq_a2))
            FaqItem(stringResource(R.string.faq_q3), stringResource(R.string.faq_a3))
            FaqItem(stringResource(R.string.faq_q4), stringResource(R.string.faq_a4))
            FaqItem(stringResource(R.string.faq_q5), stringResource(R.string.faq_a5))
            FaqItem(stringResource(R.string.faq_q6), stringResource(R.string.faq_a6))
        }
    }
}

@Composable
private fun GuideCard(title: String, content: @Composable () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

@Composable
private fun FaqItem(question: String, answer: String) {
    var expanded by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth()) {
        androidx.compose.material3.TextButton(
            onClick = { expanded = !expanded },
            modifier = Modifier.fillMaxWidth().height(48.dp),
        ) {
            Text(
                text = (if (expanded) "−  " else "+  ") + question,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
            )
        }
        if (expanded) {
            Text(answer, style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
