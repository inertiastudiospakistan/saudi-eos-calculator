package com.inertia.eoscalc.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.windowsizeclass.WindowSizeClass
import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import com.inertia.eoscalc.R

/**
 * Bottom-navigation shell: Calculator / Guide / History.
 * The layout itself is this app's own choice — a bottom bar with a top
 * app bar and a language switch — not a drawer, not a single screen.
 */
enum class EosTab { CALCULATOR, GUIDE, HISTORY }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: CalculatorViewModel,
    windowSizeClass: WindowSizeClass,
    onToggleLanguage: () -> Unit,
) {
    val state by viewModel.state.collectAsState()
    var tab by rememberSaveable { mutableStateOf(EosTab.CALCULATOR) }
    // Tablet / foldable (600dp+) -> the calculator renders two-pane;
    // the flag is threaded down rather than re-derived in each screen.
    val wide = windowSizeClass.widthSizeClass != WindowWidthSizeClass.Compact

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.app_name)) },
                actions = {
                    TextButton(onClick = onToggleLanguage) {
                        Text(stringResource(R.string.language_toggle))
                    }
                },
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == EosTab.CALCULATOR,
                    onClick = { tab = EosTab.CALCULATOR },
                    icon = { Icon(androidx.compose.material.icons.Icons.Default.Calculate, contentDescription = null) },
                    label = { Text(stringResource(R.string.tab_calculator)) },
                )
                NavigationBarItem(
                    selected = tab == EosTab.GUIDE,
                    onClick = { tab = EosTab.GUIDE },
                    icon = { Icon(androidx.compose.material.icons.Icons.Default.MenuBook, contentDescription = null) },
                    label = { Text(stringResource(R.string.tab_guide)) },
                )
                NavigationBarItem(
                    selected = tab == EosTab.HISTORY,
                    onClick = { tab = EosTab.HISTORY },
                    icon = { Icon(androidx.compose.material.icons.Icons.Default.History, contentDescription = null) },
                    label = { Text(stringResource(R.string.tab_history)) },
                )
            }
        },
    ) { padding ->
        when (tab) {
            EosTab.CALCULATOR -> CalculatorScreen(
                state = state,
                onIntent = viewModel::dispatch,
                wide = wide,
                modifier = Modifier.padding(padding),
            )
            EosTab.GUIDE -> GuideScreen(
                onLoadExample = {
                    viewModel.dispatch(CalculatorIntent.LoadExample)
                    tab = EosTab.CALCULATOR
                },
                modifier = Modifier.padding(padding),
            )
            EosTab.HISTORY -> HistoryScreen(
                state = state,
                onIntent = viewModel::dispatch,
                modifier = Modifier.padding(padding),
            )
        }
    }
}
