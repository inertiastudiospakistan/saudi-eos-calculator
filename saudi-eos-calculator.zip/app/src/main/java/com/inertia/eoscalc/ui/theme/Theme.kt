package com.inertia.eoscalc.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/**
 * Visual identity for THIS app only (App #1 in the series).
 * Deep navy #0F2040 + amber #F2A900 on a warm off-white ground.
 * Deliberately NOT the web tool's green/gold, and not a generic
 * Material purple — the series rule is that no two apps share a look.
 */
val Navy = Color(0xFF0F2040)
val NavyDeep = Color(0xFF0A1830)
val Amber = Color(0xFFF2A900)
val AmberDark = Color(0xFFC78A00)
val WarmPaper = Color(0xFFFAF7F0)
val WarmCard = Color(0xFFFFFFFF)
val InkSoft = Color(0xFF3D4A5C)

private val EosLight = lightColorScheme(
    primary = Navy,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE6F5),
    onPrimaryContainer = NavyDeep,
    secondary = AmberDark,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFEFC2),
    onSecondaryContainer = Color(0xFF4A3600),
    tertiary = Amber,
    background = WarmPaper,
    onBackground = Color(0xFF17202E),
    surface = WarmCard,
    onSurface = Color(0xFF17202E),
    surfaceVariant = Color(0xFFEDF0F4),
    onSurfaceVariant = InkSoft,
    error = Color(0xFFB3261E),
)

private val EosDark = darkColorScheme(
    primary = Color(0xFF9DB8E8),
    onPrimary = NavyDeep,
    primaryContainer = Navy,
    onPrimaryContainer = Color(0xFFDCE6F5),
    secondary = Amber,
    onSecondary = Color(0xFF241B00),
    secondaryContainer = Color(0xFF5A4300),
    onSecondaryContainer = Color(0xFFFFEFC2),
    tertiary = Amber,
    background = Color(0xFF0C1424),
    onBackground = Color(0xFFE8ECF3),
    surface = Color(0xFF131E33),
    onSurface = Color(0xFFE8ECF3),
    surfaceVariant = Color(0xFF1E2C47),
    onSurfaceVariant = Color(0xFFB9C4D6),
    error = Color(0xFFF2B8B5),
)

@Composable
fun EosCalcTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) EosDark else EosLight,
        content = content,
    )
}
