package com.inertia.eoscalc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.material3.windowsizeclass.ExperimentalMaterial3WindowSizeClassApi
import androidx.compose.material3.windowsizeclass.calculateWindowSizeClass
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.Room
import com.inertia.eoscalc.data.EosDatabase
import com.inertia.eoscalc.ui.CalculatorViewModel
import com.inertia.eoscalc.ui.MainScreen
import com.inertia.eoscalc.ui.theme.EosCalcTheme
import java.util.Locale

/**
 * Single-activity host. Edge-to-edge is on (Android 16 requirement),
 * predictive back is enabled in the manifest, and there is exactly one
 * ViewModel for the whole app — the MVI store.
 */
class MainActivity : ComponentActivity() {

    private val database by lazy {
        Room.databaseBuilder(applicationContext, EosDatabase::class.java, "eos-history.db")
            .build()
    }

    @OptIn(ExperimentalMaterial3WindowSizeClassApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EosCalcTheme {
                val vm: CalculatorViewModel = viewModel(
                    factory = object : ViewModelProvider.Factory {
                        @Suppress("UNCHECKED_CAST")
                        override fun <T : ViewModel> create(modelClass: Class<T>): T =
                            CalculatorViewModel(database.calculationDao()) as T
                    }
                )
                val windowSizeClass = calculateWindowSizeClass(this)
                MainScreen(
                    viewModel = vm,
                    windowSizeClass = windowSizeClass,
                    onToggleLanguage = { toggleLanguage() },
                )
            }
        }
    }

    /** In-app EN <-> AR toggle via per-app locales; the activity recreates. */
    private fun toggleLanguage() {
        val current = AppCompatDelegate.getApplicationLocales()
        val currentTag = current.get(0)?.language ?: Locale.getDefault().language
        val next = if (currentTag == "ar") "en" else "ar"
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(next))
    }
}
