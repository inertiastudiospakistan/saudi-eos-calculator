package com.inertia.eoscalc.domain

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.max
import kotlin.math.min

/**
 * Pure domain logic for the Saudi End-of-Service award.
 *
 * Source of truth: Saudi Labour Law (Royal Decree M/51), Articles 84 & 85,
 * as implemented and hand-checked in the companion web calculator
 * (~/workspace/goals/upwork-profile-operation/files/saudi-end-of-service-calculator/).
 *
 * Art. 84 — the award is based on the LAST monthly wage (basic wage + fixed
 * allowances): half a month's wage per year for the first 5 years, one full
 * month's wage per year after that, pro-rata for fractions of a year.
 * Art. 85 — resignation tiers, applied to the Art. 84 gross:
 *   < 2 years  -> 0
 *   2 to <5    -> 1/3
 *   5 to <10   -> 2/3
 *   10+ years  -> full
 * Employer-ended and fixed-term contract ended -> full, any duration.
 *
 * This file has NO Android dependencies so it is unit-testable on the JVM.
 */
enum class LeavingReason { EMPLOYER, CONTRACT_END, RESIGNATION }

data class EosBreakdown(
    val wage: Double,
    /** Total service in years, fractional (e.g. 7.5). */
    val serviceYears: Double,
    val reason: LeavingReason,
    /** Years counted at half a month each (<= 5). */
    val firstFiveYears: Double,
    /** Years counted at a full month each (> 5). */
    val extraYears: Double,
    /** Art. 84 amount for the first 5 years. */
    val firstPart: Double,
    /** Art. 84 amount for the years after 5. */
    val afterPart: Double,
    /** Gross Art. 84 award, before the Art. 85 factor. */
    val gross: Double,
    /** Art. 85 entitlement factor: 0, 1/3, 2/3 or 1. */
    val entitlementFactor: Double,
    /** 0..3 index into the resignation-tier scale, null when not resigning. */
    val tierIndex: Int?,
    /** Final payable award. */
    val finalAmount: Double,
    /** Final amount expressed as months of wage. */
    val monthsEquivalent: Double,
)

object EosCalculator {

    /** Days in an average month, matching the web calculator (365.25 / 12). */
    const val DAYS_PER_MONTH = 30.4375

    fun entitlementFactor(serviceYears: Double): Double = when {
        serviceYears < 2.0 -> 0.0
        serviceYears < 5.0 -> 1.0 / 3.0
        serviceYears < 10.0 -> 2.0 / 3.0
        else -> 1.0
    }

    fun tierIndex(serviceYears: Double): Int = when {
        serviceYears < 2.0 -> 0
        serviceYears < 5.0 -> 1
        serviceYears < 10.0 -> 2
        else -> 3
    }

    /**
     * Core calculation. Throws [IllegalArgumentException] for a non-positive
     * wage or service length — the UI validates before calling, the tests
     * assert this contract.
     */
    fun calculate(wage: Double, serviceYears: Double, reason: LeavingReason): EosBreakdown {
        require(wage > 0) { "Monthly wage must be greater than zero" }
        require(serviceYears > 0) { "Service length must be greater than zero" }

        val firstYears = min(serviceYears, 5.0)
        val extraYears = max(serviceYears - 5.0, 0.0)
        val firstPart = wage * firstYears * 0.5
        val afterPart = wage * extraYears
        val gross = firstPart + afterPart

        val (factor, tier) = if (reason == LeavingReason.RESIGNATION) {
            entitlementFactor(serviceYears) to tierIndex(serviceYears)
        } else {
            1.0 to null
        }
        val finalAmount = gross * factor
        return EosBreakdown(
            wage = wage,
            serviceYears = serviceYears,
            reason = reason,
            firstFiveYears = firstYears,
            extraYears = extraYears,
            firstPart = firstPart,
            afterPart = afterPart,
            gross = gross,
            entitlementFactor = factor,
            tierIndex = tier,
            finalAmount = finalAmount,
            monthsEquivalent = if (wage > 0) finalAmount / wage else 0.0,
        )
    }

    /** Years + whole months (0..11) -> fractional years. */
    fun serviceYearsFromParts(years: Int, months: Int): Double {
        require(years >= 0) { "Years cannot be negative" }
        require(months in 0..11) { "Extra months must be 0..11" }
        return years + months / 12.0
    }

    /**
     * Fractional service years from start/end dates: whole calendar months
     * plus the remaining days spread over an average month — same method as
     * the web calculator, so both tools agree to the day.
     */
    fun serviceYearsFromDates(start: LocalDate, end: LocalDate): Double {
        require(end.isAfter(start)) { "End date must be after start date" }
        val wholeMonths = ChronoUnit.MONTHS.between(start, end)
        val anchor = start.plusMonths(wholeMonths)
        val extraDays = ChronoUnit.DAYS.between(anchor, end)
        return (wholeMonths + extraDays / DAYS_PER_MONTH) / 12.0
    }
}
