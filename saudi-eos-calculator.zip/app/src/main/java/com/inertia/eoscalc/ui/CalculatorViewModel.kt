package com.inertia.eoscalc.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.inertia.eoscalc.data.CalculationDao
import com.inertia.eoscalc.data.CalculationRecord
import com.inertia.eoscalc.domain.EosBreakdown
import com.inertia.eoscalc.domain.EosCalculator
import com.inertia.eoscalc.domain.LeavingReason
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate

/**
 * MVI for the calculator screen — this app's chosen architecture.
 *
 * One [StateFlow] of [CalculatorState] is the single source of truth.
 * The UI never mutates state directly; it dispatches a [CalculatorIntent]
 * and the ViewModel reduces it into new state. Calculation is live:
 * every input intent re-runs [EosCalculator.calculate] and the result
 * (or a validation error) flows back out in the same state object.
 */
enum class DurationMode { YEARS_MONTHS, DATES }

data class CalculatorState(
    val wageText: String = "10000",
    val yearsText: String = "7",
    val monthsText: String = "0",
    val durationMode: DurationMode = DurationMode.YEARS_MONTHS,
    val startDate: LocalDate? = null,
    val endDate: LocalDate? = null,
    val reason: LeavingReason = LeavingReason.EMPLOYER,
    val result: EosBreakdown? = null,
    val error: String? = null,
    val history: List<CalculationRecord> = emptyList(),
    val justSaved: Boolean = false,
)

sealed interface CalculatorIntent {
    data class WageChanged(val text: String) : CalculatorIntent
    data class YearsChanged(val text: String) : CalculatorIntent
    data class MonthsChanged(val text: String) : CalculatorIntent
    data class ModeChanged(val mode: DurationMode) : CalculatorIntent
    data class StartDateChanged(val date: LocalDate?) : CalculatorIntent
    data class EndDateChanged(val date: LocalDate?) : CalculatorIntent
    data class ReasonChanged(val reason: LeavingReason) : CalculatorIntent
    data object SaveResult : CalculatorIntent
    data class DeleteHistory(val id: Long) : CalculatorIntent
    data object ClearHistory : CalculatorIntent
    data object LoadExample : CalculatorIntent
    data object ResetAll : CalculatorIntent
    data object DismissSaved : CalculatorIntent
}

class CalculatorViewModel(private val dao: CalculationDao) : ViewModel() {

    private val _state = MutableStateFlow(CalculatorState())
    val state: StateFlow<CalculatorState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            dao.observeAll().collect { records -> _state.update { it.copy(history = records) } }
        }
        recompute(_state.value)
    }

    fun dispatch(intent: CalculatorIntent) {
        when (intent) {
            is CalculatorIntent.WageChanged -> apply { copy(wageText = intent.text.filter { it.isDigit() }) }
            is CalculatorIntent.YearsChanged -> apply { copy(yearsText = intent.text.filter { it.isDigit() }.take(2)) }
            is CalculatorIntent.MonthsChanged -> apply { copy(monthsText = intent.text.filter { it.isDigit() }.take(2)) }
            is CalculatorIntent.ModeChanged -> apply { copy(durationMode = intent.mode) }
            is CalculatorIntent.StartDateChanged -> apply { copy(startDate = intent.date) }
            is CalculatorIntent.EndDateChanged -> apply { copy(endDate = intent.date) }
            is CalculatorIntent.ReasonChanged -> apply { copy(reason = intent.reason) }
            CalculatorIntent.LoadExample -> apply {
                copy(
                    wageText = "10000", yearsText = "7", monthsText = "0",
                    durationMode = DurationMode.YEARS_MONTHS,
                    reason = LeavingReason.EMPLOYER,
                )
            }
            CalculatorIntent.ResetAll -> _state.update {
                CalculatorState(history = it.history)
            }.also { recompute(_state.value); return }
            CalculatorIntent.SaveResult -> {
                val r = _state.value.result ?: return
                viewModelScope.launch {
                    dao.insert(
                        CalculationRecord(
                            wage = r.wage, serviceYears = r.serviceYears,
                            reason = r.reason.name, gross = r.gross,
                            finalAmount = r.finalAmount,
                            createdAtMillis = System.currentTimeMillis(),
                        )
                    )
                    _state.update { it.copy(justSaved = true) }
                }
                return
            }
            is CalculatorIntent.DeleteHistory -> {
                viewModelScope.launch { dao.deleteById(intent.id) }
                return
            }
            CalculatorIntent.ClearHistory -> {
                viewModelScope.launch { dao.deleteAll() }
                return
            }
            CalculatorIntent.DismissSaved -> {
                _state.update { it.copy(justSaved = false) }
                return
            }
        }
    }

    /** Reducer helper: apply a state transform, then recompute the result. */
    private fun apply(transform: CalculatorState.() -> CalculatorState) {
        _state.update { it.transform() }
        recompute(_state.value)
    }

    /** Live calculation. Invalid input yields a null result + an error key. */
    private fun recompute(s: CalculatorState) {
        val wage = s.wageText.toDoubleOrNull()
        if (wage == null || wage <= 0) {
            _state.update { it.copy(result = null, error = "error_wage") }
            return
        }
        val serviceYears: Double? = when (s.durationMode) {
            DurationMode.YEARS_MONTHS -> {
                val y = s.yearsText.toIntOrNull() ?: 0
                val m = s.monthsText.toIntOrNull() ?: 0
                if (m !in 0..11) null else runCatching {
                    EosCalculator.serviceYearsFromParts(y, m)
                }.getOrNull()
            }
            DurationMode.DATES -> {
                val start = s.startDate
                val end = s.endDate
                if (start == null || end == null) null else runCatching {
                    EosCalculator.serviceYearsFromDates(start, end)
                }.getOrNull()
            }
        }
        if (serviceYears == null || serviceYears <= 0) {
            _state.update { it.copy(result = null, error = "error_duration") }
            return
        }
        val result = runCatching { EosCalculator.calculate(wage, serviceYears, s.reason) }.getOrNull()
        _state.update { it.copy(result = result, error = if (result == null) "error_duration" else null) }
    }
}
