package com.inertia.eoscalc.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.inertia.eoscalc.R
import com.inertia.eoscalc.domain.EosBreakdown
import com.inertia.eoscalc.domain.LeavingReason
import com.inertia.eoscalc.ui.CalculatorIntent
import com.inertia.eoscalc.ui.CalculatorState
import com.inertia.eoscalc.ui.DurationMode
import com.inertia.eoscalc.ui.theme.Amber
import com.inertia.eoscalc.ui.theme.Navy
import java.text.NumberFormat
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale
import kotlin.math.roundToLong

/** Whole-SAR formatting, matching the web tool (no decimals on amounts). */
internal fun fmtSar(amount: Double): String =
    NumberFormat.getNumberInstance(Locale.US).format(amount.roundToLong())

internal fun fmtYears(years: Double): String {
    val rounded = (years * 100).roundToLong() / 100.0
    return if (rounded == rounded.toLong().toDouble()) rounded.toLong().toString()
    else String.format(Locale.US, "%.2f", rounded)
}

private val CardShape = RoundedCornerShape(20.dp)
private const val MIN_TOUCH = 48 // dp — every interactive row is at least 48dp tall.

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen(
    state: CalculatorState,
    onIntent: (CalculatorIntent) -> Unit,
    wide: Boolean,
    modifier: Modifier = Modifier,
) {
    val form = @Composable {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            WageCard(state, onIntent)
            DurationCard(state, onIntent)
            ReasonCard(state, onIntent)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(
                    onClick = { onIntent(CalculatorIntent.ResetAll) },
                    modifier = Modifier.height(MIN_TOUCH.dp).weight(1f),
                ) { Text(stringResource(R.string.reset)) }
            }
        }
    }
    val result = @Composable {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            state.result?.let { ResultCard(it, state.reason, onIntent) }
                ?: ErrorCard(state.error)
            DisclaimerText()
        }
    }

    if (wide) {
        // Tablet / foldable 600dp+: form left, live result right, side by side.
        Row(
            modifier = modifier.fillMaxSize().padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Box(Modifier.weight(1f).verticalScroll(rememberScrollState())) { form() }
            Box(Modifier.weight(1f).verticalScroll(rememberScrollState())) { result() }
        }
    } else {
        Column(
            modifier = modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            form()
            result()
        }
    }
}

@Composable
private fun WageCard(state: CalculatorState, onIntent: (CalculatorIntent) -> Unit) {
    Card(shape = CardShape, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text(stringResource(R.string.wage_label), style = MaterialTheme.typography.titleMedium)
            Text(stringResource(R.string.wage_hint), style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = state.wageText,
                onValueChange = { onIntent(CalculatorIntent.WageChanged(it)) },
                label = { Text(stringResource(R.string.wage_field_label)) },
                suffix = { Text(stringResource(R.string.currency_sar)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                isError = state.error == "error_wage",
                modifier = Modifier.fillMaxWidth().height(64.dp),
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DurationCard(state: CalculatorState, onIntent: (CalculatorIntent) -> Unit) {
    var showStartPicker by remember { mutableStateOf(false) }
    var showEndPicker by remember { mutableStateOf(false) }
    Card(shape = CardShape, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(stringResource(R.string.duration_label), style = MaterialTheme.typography.titleMedium)
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = state.durationMode == DurationMode.YEARS_MONTHS,
                    onClick = { onIntent(CalculatorIntent.ModeChanged(DurationMode.YEARS_MONTHS)) },
                    shape = SegmentedButtonDefaults.itemShape(0, 2),
                ) { Text(stringResource(R.string.mode_years_months)) }
                SegmentedButton(
                    selected = state.durationMode == DurationMode.DATES,
                    onClick = { onIntent(CalculatorIntent.ModeChanged(DurationMode.DATES)) },
                    shape = SegmentedButtonDefaults.itemShape(1, 2),
                ) { Text(stringResource(R.string.mode_dates)) }
            }
            if (state.durationMode == DurationMode.YEARS_MONTHS) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = state.yearsText,
                        onValueChange = { onIntent(CalculatorIntent.YearsChanged(it)) },
                        label = { Text(stringResource(R.string.years_label)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = state.monthsText,
                        onValueChange = { onIntent(CalculatorIntent.MonthsChanged(it)) },
                        label = { Text(stringResource(R.string.months_label)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                }
            } else {
                DateRow(stringResource(R.string.start_date), state.startDate) { showStartPicker = true }
                DateRow(stringResource(R.string.end_date), state.endDate) { showEndPicker = true }
            }
            state.result?.let {
                Text(
                    stringResource(R.string.duration_summary, fmtYears(it.serviceYears)),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }
    }
    if (showStartPicker) {
        DatePickerSheet(
            onDismiss = { showStartPicker = false },
            onPicked = { onIntent(CalculatorIntent.StartDateChanged(it)); showStartPicker = false },
        )
    }
    if (showEndPicker) {
        DatePickerSheet(
            onDismiss = { showEndPicker = false },
            onPicked = { onIntent(CalculatorIntent.EndDateChanged(it)); showEndPicker = false },
        )
    }
}

@Composable
private fun DateRow(label: String, date: LocalDate?, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(MIN_TOUCH.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(
            date?.toString() ?: "—",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DatePickerSheet(onDismiss: () -> Unit, onPicked: (LocalDate) -> Unit) {
    val pickerState = rememberDatePickerState()
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                pickerState.selectedDateMillis?.let { millis ->
                    onPicked(Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate())
                } ?: onDismiss()
            }) { Text(stringResource(R.string.ok)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        },
    ) { DatePicker(state = pickerState) }
}

@Composable
private fun ReasonCard(state: CalculatorState, onIntent: (CalculatorIntent) -> Unit) {
    Card(shape = CardShape, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(stringResource(R.string.reason_label), style = MaterialTheme.typography.titleMedium)
            ReasonOption(
                selected = state.reason == LeavingReason.EMPLOYER,
                title = stringResource(R.string.reason_employer),
                desc = stringResource(R.string.reason_employer_desc),
                badge = stringResource(R.string.badge_full),
                onClick = { onIntent(CalculatorIntent.ReasonChanged(LeavingReason.EMPLOYER)) },
            )
            ReasonOption(
                selected = state.reason == LeavingReason.CONTRACT_END,
                title = stringResource(R.string.reason_contract),
                desc = stringResource(R.string.reason_contract_desc),
                badge = stringResource(R.string.badge_full),
                onClick = { onIntent(CalculatorIntent.ReasonChanged(LeavingReason.CONTRACT_END)) },
            )
            ReasonOption(
                selected = state.reason == LeavingReason.RESIGNATION,
                title = stringResource(R.string.reason_resign),
                desc = stringResource(R.string.reason_resign_desc),
                badge = stringResource(R.string.badge_art85),
                onClick = { onIntent(CalculatorIntent.ReasonChanged(LeavingReason.RESIGNATION)) },
            )
        }
    }
}

@Composable
private fun ReasonOption(selected: Boolean, title: String, desc: String, badge: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(72.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(
                if (selected) MaterialTheme.colorScheme.primaryContainer
                else MaterialTheme.colorScheme.surfaceVariant,
            )
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Column(Modifier.weight(1f).padding(start = 8.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(badge, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun ResultCard(
    result: EosBreakdown,
    reason: LeavingReason,
    onIntent: (CalculatorIntent) -> Unit,
) {
    val context = LocalContext.current
    Card(
        shape = CardShape,
        colors = CardDefaults.cardColors(containerColor = Navy, contentColor = androidx.compose.ui.graphics.Color.White),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(stringResource(R.string.result_title), style = MaterialTheme.typography.titleMedium)
            Text(stringResource(R.string.final_label), style = MaterialTheme.typography.bodyMedium,
                color = androidx.compose.ui.graphics.Color(0xFFB9C4D6))
            Text(
                text = "${fmtSar(result.finalAmount)} ${stringResource(R.string.currency_sar)}",
                style = MaterialTheme.typography.displaySmall,
                fontWeight = FontWeight.Bold,
            )
            Text(
                stringResource(R.string.months_equiv, fmtYears(result.monthsEquivalent)),
                style = MaterialTheme.typography.bodyMedium,
                color = Amber,
            )
            if (result.finalAmount == 0.0 && reason == LeavingReason.RESIGNATION) {
                Text(stringResource(R.string.zero_note), style = MaterialTheme.typography.bodySmall,
                    color = Amber)
            }
            // Step-by-step breakdown (Art. 84, then Art. 85 factor).
            BreakdownRow(stringResource(R.string.part1_label, fmtYears(result.firstFiveYears)), fmtSar(result.firstPart))
            BreakdownRow(stringResource(R.string.part2_label, fmtYears(result.extraYears)), fmtSar(result.afterPart))
            BreakdownRow(stringResource(R.string.gross_label), fmtSar(result.gross))
            if (reason == LeavingReason.RESIGNATION) {
                val factorText = when (result.entitlementFactor) {
                    0.0 -> "× 0"
                    1.0 / 3.0 -> "× ⅓"
                    2.0 / 3.0 -> "× ⅔"
                    else -> "× 1"
                }
                BreakdownRow(stringResource(R.string.factor_label), factorText)
            }
            BreakdownRow(stringResource(R.string.total_label), "${fmtSar(result.finalAmount)} ${stringResource(R.string.currency_sar)}", bold = true)
            // Distribution bar: first-5-years share vs after-5-years share.
            if (result.gross > 0) {
                val firstShare = (result.firstPart / result.gross).toFloat()
                Row(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(7.dp))) {
                    Box(Modifier.weight(firstShare.coerceAtLeast(0.01f)).background(Amber))
                    Box(Modifier.weight((1f - firstShare).coerceAtLeast(0.01f)).background(androidx.compose.ui.graphics.Color(0xFF4CC084)))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text(stringResource(R.string.bar_first), style = MaterialTheme.typography.labelSmall)
                    Text(stringResource(R.string.bar_after), style = MaterialTheme.typography.labelSmall)
                }
            }
            // Resignation tier indicator (Art. 85).
            if (reason == LeavingReason.RESIGNATION && result.tierIndex != null) {
                Text(stringResource(R.string.tier_label), style = MaterialTheme.typography.titleSmall)
                val tiers = listOf(
                    stringResource(R.string.tier_none),
                    stringResource(R.string.tier_third),
                    stringResource(R.string.tier_two_thirds),
                    stringResource(R.string.tier_full),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    tiers.forEachIndexed { index, label ->
                        val active = index == result.tierIndex
                        Box(
                            Modifier.weight(1f).height(MIN_TOUCH.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (active) Amber else androidx.compose.ui.graphics.Color(0x33FFFFFF)),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                label, textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (active) Navy else androidx.compose.ui.graphics.Color.White,
                                fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                            )
                        }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { onIntent(CalculatorIntent.SaveResult) },
                    colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Navy),
                    modifier = Modifier.height(MIN_TOUCH.dp).weight(1f),
                ) { Text(stringResource(R.string.save_history)) }
                OutlinedButton(
                    onClick = { copyResult(context, result) },
                    modifier = Modifier.height(MIN_TOUCH.dp).weight(1f),
                ) { Text(stringResource(R.string.copy_result)) }
                OutlinedButton(
                    onClick = { shareResult(context, result) },
                    modifier = Modifier.height(MIN_TOUCH.dp).weight(1f),
                ) { Text(stringResource(R.string.share_result)) }
            }
        }
    }
}

@Composable
private fun BreakdownRow(label: String, value: String, bold: Boolean = false) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
        Text(value, style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ErrorCard(error: String?) {
    Card(
        shape = CardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(20.dp)) {
            Text(
                stringResource(
                    when (error) {
                        "error_wage" -> R.string.error_wage
                        else -> R.string.error_duration
                    }
                ),
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

@Composable
private fun DisclaimerText() {
    Text(
        stringResource(R.string.disclaimer),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

private fun resultText(result: EosBreakdown): String = buildString {
    appendLine("End-of-Service Award — Saudi Labour Law (Arts. 84 & 85)")
    appendLine("Last monthly wage: ${fmtSar(result.wage)} SAR")
    appendLine("Service: ${fmtYears(result.serviceYears)} years")
    appendLine("First 5 years: ${fmtSar(result.firstPart)} SAR")
    appendLine("After 5 years: ${fmtSar(result.afterPart)} SAR")
    appendLine("Gross (Art. 84): ${fmtSar(result.gross)} SAR")
    appendLine("Payable award: ${fmtSar(result.finalAmount)} SAR")
    append("Estimate only — not legal advice.")
}

private fun copyResult(context: Context, result: EosBreakdown) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("EOS result", resultText(result)))
}

private fun shareResult(context: Context, result: EosBreakdown) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, resultText(result))
    }
    context.startActivity(Intent.createChooser(intent, "Share result"))
}
