package com.inertia.eoscalc.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.inertia.eoscalc.R
import com.inertia.eoscalc.data.CalculationRecord
import com.inertia.eoscalc.domain.LeavingReason
import com.inertia.eoscalc.ui.CalculatorIntent
import com.inertia.eoscalc.ui.CalculatorState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * History tab — saved calculations, stored only on this device (Room).
 * Newest first. Nothing here is ever uploaded anywhere.
 */
@Composable
fun HistoryScreen(
    state: CalculatorState,
    onIntent: (CalculatorIntent) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(stringResource(R.string.history_title), style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold)
        if (state.history.isEmpty()) {
            Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Text(
                    stringResource(R.string.history_empty),
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(20.dp),
                )
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)) {
                items(state.history, key = { it.id }) { record ->
                    HistoryRow(record, onDelete = { onIntent(CalculatorIntent.DeleteHistory(record.id)) })
                }
            }
            OutlinedButton(
                onClick = { onIntent(CalculatorIntent.ClearHistory) },
                modifier = Modifier.fillMaxWidth().height(48.dp),
            ) { Text(stringResource(R.string.clear_all)) }
        }
        Spacer(Modifier.height(4.dp))
    }
}

@Composable
private fun HistoryRow(record: CalculationRecord, onDelete: () -> Unit) {
    val date = SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault())
        .format(Date(record.createdAtMillis))
    val reasonText = when (record.leavingReason) {
        LeavingReason.EMPLOYER -> stringResource(R.string.reason_employer)
        LeavingReason.CONTRACT_END -> stringResource(R.string.reason_contract)
        LeavingReason.RESIGNATION -> stringResource(R.string.reason_resign)
    }
    Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    "${fmtSar(record.finalAmount)} ${stringResource(R.string.currency_sar)}",
                    style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                )
                Text(
                    stringResource(
                        R.string.history_subtitle,
                        fmtYears(record.serviceYears),
                        fmtSar(record.wage),
                        reasonText,
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(date, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onDelete, modifier = Modifier.height(48.dp)) {
                Text("✕", style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}
