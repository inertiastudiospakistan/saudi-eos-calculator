package com.inertia.eoscalc.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import com.inertia.eoscalc.domain.LeavingReason
import kotlinx.coroutines.flow.Flow

/**
 * Local-only history. Room, on-device only — nothing leaves the phone.
 * No account, no sync, no network. Deleting the app deletes the history.
 */
@Entity(tableName = "calculations")
data class CalculationRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val wage: Double,
    val serviceYears: Double,
    val reason: String, // LeavingReason.name
    val gross: Double,
    val finalAmount: Double,
    val createdAtMillis: Long,
) {
    val leavingReason: LeavingReason get() = LeavingReason.valueOf(reason)
}

@Dao
interface CalculationDao {
    @Insert
    suspend fun insert(record: CalculationRecord): Long

    @Query("SELECT * FROM calculations ORDER BY createdAtMillis DESC")
    fun observeAll(): Flow<List<CalculationRecord>>

    @Query("DELETE FROM calculations WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM calculations")
    suspend fun deleteAll()
}

@Database(entities = [CalculationRecord::class], version = 1, exportSchema = false)
abstract class EosDatabase : RoomDatabase() {
    abstract fun calculationDao(): CalculationDao
}
