# Saudi EOS Calculator — keep Room entities/DAOs and the public domain API.
-keep class com.inertia.eoscalc.data.** { *; }
-keep class com.inertia.eoscalc.domain.** { *; }
-dontwarn androidx.room.**
