# Saudi EOS Calculator — App #1 in the series

Native Android app that calculates the Saudi End-of-Service award under
Articles 84 & 85 of the Saudi Labour Law (Royal Decree M/51). Fully offline,
no ads, no analytics, no login, no permissions at all.

Package: `com.inertia.eoscalc` · version 1.0.0 (versionCode 1)

## The calculation (verified, do not change without re-checking)

Art. 84 — based on the LAST monthly wage (basic + fixed allowances):
half a month's wage per year for the first 5 years, one full month per
year after that, pro-rata for fractions of a year.

Art. 85 — resignation tiers applied to the Art. 84 gross:
< 2 yrs = 0 · 2 to <5 yrs = 1/3 · 5 to <10 yrs = 2/3 · 10+ yrs = full.
Employer-ended and fixed-term contract ended = full, any duration.

Worked checks (also unit-tested in `EosCalculatorTest`):
- 10,000 SAR, 7 yrs, employer-ended → 45,000 (25,000 + 20,000)
- 10,000 SAR, 7 yrs, resignation → 30,000 (45,000 × ⅔)
- 10,000 SAR, 3 yrs, resignation → 5,000 (15,000 × ⅓)
- 10,000 SAR, 12 yrs, employer-ended → 95,000 (25,000 + 70,000)

## How THIS app is different (series rule)

Every app in the series must look and feel like it came from a different
developer. This app's own choices — do not copy them into the next app:

| Aspect | This app (#1) |
|---|---|
| Architecture | **MVI** — one ViewModel, one `StateFlow<CalculatorState>`, sealed `CalculatorIntent` / reducer. UI dispatches intents only, never mutates state. |
| UI language | Bottom navigation, 3 tabs (Calculator / Guide / History); large rounded cards (20dp); navy result card with amber accents |
| Colours | Deep navy `#0F2040` + amber `#F2A900` on warm off-white `#FAF7F0` — NOT the web tool's green/gold |
| Navigation | Bottom bar + top app bar with in-app EN/AR language switch; no drawer, no single-screen form |
| Data | Room database for History, on-device only |
| Language | Kotlin + Jetpack Compose only, no WebView |

## Modern-device optimisation

- `targetSdk 36` (Android 16), `compileSdk 36`, `minSdk 26`
- Edge-to-edge (`enableEdgeToEdge()`), predictive back
  (`android:enableOnBackInvokedCallback="true"`)
- Dark mode via `isSystemInDarkTheme()`; RTL Arabic + English full
  `strings.xml` (`values/` and `values-ar/`), in-app toggle via
  per-app locales (`AppCompatDelegate.setApplicationLocales`)
- Large screens: `WindowSizeClass` — phone = single column,
  600dp+ (tablet/foldable) = two-pane calculator + result side by side
- Touch targets ≥ 48dp, accessibility labels on interactive rows,
  no hard-coded pixel sizes that break on small/large screens

## Build

Prerequisites: JDK 17, Android SDK with platform 36 + build-tools 36,
`ANDROID_HOME` / `ANDROID_SDK_ROOT` set to the SDK location.

```bash
./gradlew assembleDebug        # debug APK
./gradlew bundleRelease        # release AAB (signed with the debug keystore
                               # in this repo for local testing only)
./gradlew testDebugUnitTest    # unit tests for the calculator logic
```

The release bundle in this repo is signed with a **debug keystore**
(`app/debug.keystore`, the standard `android`/`androiddebugkey`
credentials). That is a local-testing convenience only. For Play:
create a real upload key in Play Console and let Play App Signing
re-sign — do NOT ship the debug keystore as a production key.

## Privacy

The app collects nothing. See `PRIVACY.md`. History is stored in a
local Room database on the device and is deleted with the app.

## Build status — 20 Nov 2026 (read before rebuilding)

Environment installed on this VM (do not reinstall):
- JDK: Temurin 17.0.21.1 at `/opt/jdk-17` (`JAVA_HOME=/opt/jdk-17`)
- Gradle: 8.9 at `/opt/gradle-8.9`
- Android SDK at `~/Android/Sdk` (`ANDROID_HOME`/`ANDROID_SDK_ROOT`):
  platform `android-36`, build-tools `36.0.0`, platform-tools,
  cmdline-tools `latest`, licences accepted. Platform zip SHA-1
  verified: `2c1a80dd4d9f7d0e6dd336ec603d9b5c55a6f576`.
- Gradle wrapper files are in place (`gradlew`,
  `gradle/wrapper/gradle-wrapper.{jar,properties}`, Gradle 8.9).

Verified on 20 Nov 2026 WITHOUT Gradle (see below why):
- Unit tests: **15/15 pass** — compiled with the real Kotlin 2.0.21
  compiler (`kotlin-compiler-embeddable`) and run under JUnit 4.13.2,
  including all four worked checks (45,000 / 30,000 / 5,000 / 95,000).
  One test expectation was fixed during verification (10-year
  resignation is 75,000, not 50,000 — the code was right, the test
  arithmetic was wrong).
- Resources: `aapt2 compile` + `aapt2 link` succeed; `R.java`
  generated for `com.inertia.eoscalc`; badging confirms package,
  `compileSdkVersion 36`, EN + AR labels, launcher activity and
  adaptive icon. With `targetSdkVersion 36` the APK declares
  **zero permissions**.
- Strings: EN and AR `strings.xml` have identical key sets (78 keys),
  no format-argument mismatches.
- Debug keystore created at `app/debug.keystore`.

NOT yet run — one sandbox blocker:
`./gradlew assembleDebug` and `./gradlew bundleRelease` cannot run
here yet. Gradle's client and its daemon talk over loopback TCP, and
this sandbox intercepts **outgoing TCP from Java processes** with:
`muse: Other TCP connections is turned off for this assistant.`
Proven by experiment: a Java client cannot reach a Java server on
127.0.0.1 (gets that message as the reply), while a Python client
reaches the same Java server fine. The daemon starts and listens
correctly; the client connects to the interceptor instead, so every
Gradle invocation fails with `Could not receive a message from the
daemon.` Java also cannot use the egress proxy directly
(`HttpURLConnection` tunnelling fails the same way), which is why the
SDK was installed by downloading the packages with curl instead.

Fix (one user action, then the build works): in Muse settings →
Permissions → Direct network protocols, switch `other_tcp` from
**Deny** to **Ask**. Then run, with the proxy env vars available:

```bash
export JAVA_HOME=/opt/jdk-17
export ANDROID_HOME=$HOME/Android/Sdk
export ANDROID_SDK_ROOT=$HOME/Android/Sdk
cd ~/workspace/android-apps/saudi-eos-calculator
./gradlew testDebugUnitTest assembleDebug bundleRelease
```

Notes for the follow-up run: `/tmp` is a 512 MB tmpfs that fills up
— put downloads in `~/workspace/android-sdk-downloads/`, never `/tmp`.
Gradle also needs the egress proxy for dependency downloads; pass the
proxy host/port/user/password as `-Dhttps.proxyHost=…` etc. on the
Gradle command line (do NOT write the password into
`gradle.properties`). The egress CA certs were imported into
`/opt/jdk-17/lib/security/cacerts` (alias prefix `hatch-cert`).

