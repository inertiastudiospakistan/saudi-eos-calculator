# Play Listing Checklist — Saudi EOS Calculator (App #1)

## Store listing (draft copy)

- **Title:** Saudi EOS Calculator — End of Service
- **Short description (80 chars):** Saudi end-of-service award calculator — Articles 84 & 85, offline, in English & Arabic.
- **Full description:** Calculate your Saudi end-of-service award under Articles 84 & 85 of the Saudi Labour Law. Enter your last monthly wage and length of service — by years and months, or by start and end dates — choose how the employment ended, and see the full step-by-step breakdown instantly: first 5 years at half a month per year, later years at a full month, and the Article 85 resignation tiers. Works fully offline, in English and Arabic, with a guide to the law, a worked example, and a private on-device history of your saved calculations. Estimate only — not legal advice.
- **Category:** Finance (or Tools — Finance fits the award calculation best)
- **Tags:** end of service, Saudi Labour Law, EOSB, مكافأة نهاية الخدمة

## Data Safety form — answers for this app

- **Does the app collect or share any user data?** NO — no data collected, no data shared.
- **Location, personal info, financial info, messages, photos, audio, files, health, contacts, identifiers, device IDs:** none collected.
- **Data deletion:** nothing to delete server-side (nothing is stored off-device). On-device history is deleted by the user in-app or by uninstalling.
- **Encryption in transit:** not applicable — the app makes no network connections.
- **Privacy policy URL:** host `PRIVACY.md` (this file) on a public URL and paste it here.

## Content rating questionnaire

- No violence, no sexual content, no gambling, no user-generated content, no chat, no ads, no in-app purchases, no login, no location. Expect **Everyone / PEGI 3**.
- Note for the reviewer: this is a finance calculator, not a gambling or betting app.

## What Google checks on the first app (be ready)

1. **Target API:** 36 (Android 16) — set in `app/build.gradle.kts`.
2. **AAB format** for the release track; Play App Signing re-signs.
3. **Closed testing (new personal account):** 12 real testers, opted in, using the app for 14 consecutive days, then the production-access application. Fake/tester-farm accounts will get the account rejected — use real people.
4. **Privacy policy link** must open (host PRIVACY.md publicly).
5. **Screenshots must show the real app** — no mockups, no placeholder text.

## Screenshots still needed (take on a real phone, not the emulator if possible)

- [ ] Phone: Calculator tab, default example (10,000 SAR / 7 yrs, employer-ended → 45,000)
- [ ] Phone: Calculator tab, resignation tier indicator visible
- [ ] Phone: Guide tab (Article 84/85)
- [ ] Phone: History tab with at least one saved calculation
- [ ] Phone: Arabic (RTL) calculator screen
- [ ] 7-inch tablet: two-pane layout (form + result side by side)
- [ ] Feature graphic 1024 × 500 (navy #0F2040 background, amber accent, app name)
- [ ] App icon 512 × 512 (from `ic_launcher_foreground` artwork)

## Pre-submit self-check

- [ ] `./gradlew bundleRelease` succeeds; AAB installs and opens
- [ ] No crashes rotating the phone, switching language, or going offline
- [ ] Calculation matches the worked example: 10,000 / 7 yrs → 45,000 employer, 30,000 resignation
- [ ] History save / delete / clear-all works
- [ ] Dark mode renders correctly on every tab
- [ ] No permission prompts appear at any point
